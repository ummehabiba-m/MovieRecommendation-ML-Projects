from prefect import flow, task
from prefect.tasks import exponential_backoff
from prefect_email import EmailServerCredentials, email_send_message
from loguru import logger
import pandas as pd
from typing import Tuple, Dict, Any
from pathlib import Path
import sys

# Add src to path
sys.path.append(str(Path(__file__).parent))

from data_loader import MovieLensDataLoader
from feature_engineering import FeatureEngineer
from feature_store import FeatureStoreManager
from model_training import ModelTrainer, ModelEvaluator
import config.config as config


@task(
    name="download_data",
    description="Download MovieLens 100K dataset",
    retries=3,
    retry_delay_seconds=exponential_backoff(backoff_factor=2)
)
def download_data_task() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Task: Download and load raw data"""
    try:
        logger.info("Starting data download task...")
        loader = MovieLensDataLoader()
        ratings, movies, users = loader.load_all_data()
        
        logger.info(f"✓ Data loaded: {len(ratings)} ratings, {len(movies)} movies, {len(users)} users")
        return ratings, movies, users
        
    except Exception as e:
        logger.error(f"✗ Data download failed: {e}")
        raise


@task(
    name="engineer_features",
    description="Engineer features from raw data",
    retries=2
)
def engineer_features_task(
    ratings: pd.DataFrame,
    movies: pd.DataFrame,
    users: pd.DataFrame
) -> pd.DataFrame:
    """Task: Feature engineering"""
    try:
        logger.info("Starting feature engineering task...")
        engineer = FeatureEngineer()
        features_df = engineer.engineer_features(ratings, movies, users)
        
        logger.info(f"✓ Features engineered: shape={features_df.shape}")
        return features_df
        
    except Exception as e:
        logger.error(f"✗ Feature engineering failed: {e}")
        raise


@task(
    name="save_to_feature_store",
    description="Save features to Hopsworks Feature Store",
    retries=3,
    retry_delay_seconds=exponential_backoff(backoff_factor=2)
)
def save_to_feature_store_task(features_df: pd.DataFrame) -> bool:
    """Task: Save features to feature store"""
    try:
        logger.info("Starting feature store upload task...")
        fs_manager = FeatureStoreManager()
        fs_manager.connect()
        
        # Create feature group
        fs_manager.create_feature_group(features_df)
        
        # Create feature view
        fs_manager.create_feature_view()
        
        logger.info("✓ Features saved to Feature Store")
        return True
        
    except Exception as e:
        logger.error(f"✗ Feature store upload failed: {e}")
        logger.warning("Continuing without feature store (for local development)")
        
        # Save locally as backup
        local_path = config.DATA_DIR / "processed" / "features.parquet"
        features_df.to_parquet(local_path)
        logger.info(f"✓ Features saved locally to {local_path}")
        
        return False


@task(
    name="prepare_training_data",
    description="Prepare training and test datasets"
)
def prepare_training_data_task(
    features_df: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Task: Prepare train-test split"""
    try:
        logger.info("Preparing training data...")
        
        # Get feature columns
        engineer = FeatureEngineer()
        feature_cols = engineer.get_feature_columns()
        
        # Ensure all feature columns exist
        missing_cols = [col for col in feature_cols if col not in features_df.columns]
        if missing_cols:
            logger.warning(f"Missing columns: {missing_cols}")
            feature_cols = [col for col in feature_cols if col in features_df.columns]
        
        # Prepare features and target
        X = features_df[feature_cols].copy()
        y = features_df['rating'].copy()
        
        # Handle missing values
        X = X.fillna(X.mean())
        
        # Time-based split (more realistic for time series)
        split_idx = int(len(X) * config.TRAIN_TEST_SPLIT_RATIO)
        X_train = X.iloc[:split_idx]
        X_test = X.iloc[split_idx:]
        y_train = y.iloc[:split_idx]
        y_test = y.iloc[split_idx:]
        
        logger.info(f"✓ Training data prepared: train={X_train.shape}, test={X_test.shape}")
        return X_train, X_test, y_train, y_test
        
    except Exception as e:
        logger.error(f"✗ Data preparation failed: {e}")
        raise


@task(
    name="train_models",
    description="Train multiple ML models",
    retries=1
)
def train_models_task(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series
) -> Dict[str, Any]:
    """Task: Train and evaluate models"""
    try:
        logger.info("Starting model training task...")
        
        trainer = ModelTrainer()
        results = trainer.train_all_models(X_train, y_train, X_test, y_test)
        
        # Save best model
        model_path = trainer.save_best_model()
        
        logger.info(f"✓ Models trained. Best model saved to {model_path}")
        
        return {
            'results': results,
            'best_model': trainer.best_model_name,
            'best_metrics': trainer.best_metrics,
            'model_path': str(model_path)
        }
        
    except Exception as e:
        logger.error(f"✗ Model training failed: {e}")
        raise


@task(
    name="evaluate_model",
    description="Detailed model evaluation"
)
def evaluate_model_task(
    training_results: Dict[str, Any],
    X_test: pd.DataFrame,
    y_test: pd.Series
) -> Dict[str, Any]:
    """Task: Evaluate model performance"""
    try:
        logger.info("Starting model evaluation task...")
        
        best_model_name = training_results['best_model']
        best_model = training_results['results'][best_model_name]['model']
        
        # Make predictions
        y_pred = best_model.predict(X_test)
        
        # Detailed evaluation
        evaluator = ModelEvaluator()
        evaluation_results = evaluator.evaluate_predictions(
            y_test.values,
            y_pred
        )
        
        logger.info("✓ Model evaluation complete")
        logger.info(f"  RMSE: {evaluation_results['overall']['rmse']:.4f}")
        logger.info(f"  MAE: {evaluation_results['overall']['mae']:.4f}")
        logger.info(f"  R²: {evaluation_results['overall']['r2']:.4f}")
        
        return evaluation_results
        
    except Exception as e:
        logger.error(f"✗ Model evaluation failed: {e}")
        raise


@task(
    name="send_notification",
    description="Send notification on pipeline completion"
)
def send_notification_task(
    success: bool,
    training_results: Dict[str, Any] = None,
    error_message: str = None
):
    """Task: Send notification"""
    try:
        if success:
            message = f"""
            ✅ ML Pipeline Completed Successfully!
            
            Best Model: {training_results['best_model']}
            Test RMSE: {training_results['best_metrics']['rmse']:.4f}
            Test MAE: {training_results['best_metrics']['mae']:.4f}
            Test R²: {training_results['best_metrics']['r2']:.4f}
            
            Model saved to: {training_results['model_path']}
            """
        else:
            message = f"""
            ❌ ML Pipeline Failed!
            
            Error: {error_message}
            """
        
        logger.info(message)
        
        # Send Discord notification if webhook configured
        if config.DISCORD_WEBHOOK_URL:
            import requests
            requests.post(
                config.DISCORD_WEBHOOK_URL,
                json={"content": message}
            )
            logger.info("✓ Discord notification sent")
        
        return True
        
    except Exception as e:
        logger.warning(f"Failed to send notification: {e}")
        return False


@flow(
    name="movielens_training_pipeline",
    description="End-to-end ML training pipeline for MovieLens",
    log_prints=True
)
def training_pipeline():
    """Main training pipeline flow"""
    try:
        logger.info("=" * 80)
        logger.info("🚀 Starting MovieLens ML Training Pipeline")
        logger.info("=" * 80)
        
        # Step 1: Download data
        ratings, movies, users = download_data_task()
        
        # Step 2: Engineer features
        features_df = engineer_features_task(ratings, movies, users)
        
        # Step 3: Save to feature store
        save_to_feature_store_task(features_df)
        
        # Step 4: Prepare training data
        X_train, X_test, y_train, y_test = prepare_training_data_task(features_df)
        
        # Step 5: Train models
        training_results = train_models_task(X_train, y_train, X_test, y_test)
        
        # Step 6: Evaluate model
        evaluation_results = evaluate_model_task(training_results, X_test, y_test)
        
        # Step 7: Send success notification
        send_notification_task(True, training_results)
        
        logger.info("=" * 80)
        logger.info("✅ Pipeline completed successfully!")
        logger.info("=" * 80)
        
        return {
            'status': 'success',
            'training_results': training_results,
            'evaluation_results': evaluation_results
        }
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        send_notification_task(False, error_message=str(e))
        raise


@flow(
    name="movielens_inference_pipeline",
    description="Inference pipeline for batch predictions"
)
def inference_pipeline(user_ids: list, item_ids: list):
    """Inference pipeline for batch predictions"""
    logger.info("Starting inference pipeline...")
    
    # Load model and make predictions
    # Implementation here
    
    logger.info("Inference complete")


if __name__ == "__main__":
    # Run the training pipeline
    training_pipeline()
